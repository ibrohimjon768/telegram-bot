require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'change_this_secret';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

app.use(helmet());
app.use(cors({ origin: '*', credentials: true }));
app.use(express.json());
app.use(express.static(__dirname)); // Serve index.html & search.html

function generateToken(payload){
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}

function authMiddleware(req, res, next){
  const auth = req.headers.authorization;
  if(!auth || !auth.startsWith('Bearer ')) return res.status(401).json({ error: 'Unauthorized' });
  const token = auth.slice(7);
  try{
    const data = jwt.verify(token, JWT_SECRET);
    req.user = data;
    next();
  }catch(e){
    return res.status(401).json({ error: 'Invalid token' });
  }
}

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.post('/api/signup', async (req, res) => {
  try{
    const { name, email, password } = req.body;
    if(!name || !email || !password) return res.status(400).json({ error: 'Missing fields' });
    if(password.length < 6) return res.status(400).json({ error: 'Password too short' });

    db.get('SELECT id FROM users WHERE email = ?', [email.toLowerCase()], async (err, row) => {
      if(err) return res.status(500).json({ error: 'DB error' });
      if(row) return res.status(409).json({ error: 'Email already registered' });

      const hash = await bcrypt.hash(password, 12);
      const stmt = db.prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)');
      stmt.run(name, email.toLowerCase(), hash, function(insertErr){
        if(insertErr) return res.status(500).json({ error: 'DB insert error' });
        const user = { id: this.lastID, name, email: email.toLowerCase() };
        const token = generateToken({ id: user.id, email: user.email });
        return res.json({ success: true, user, token });
      });
    });
  }catch(e){
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  if(!email || !password) return res.status(400).json({ error: 'Missing fields' });

  db.get('SELECT id, name, email, password_hash FROM users WHERE email = ?', [email.toLowerCase()], async (err, row) => {
    if(err) return res.status(500).json({ error: 'DB error' });
    if(!row) return res.status(401).json({ error: 'Invalid credentials' });

    const ok = await bcrypt.compare(password, row.password_hash);
    if(!ok) return res.status(401).json({ error: 'Invalid credentials' });

    const token = generateToken({ id: row.id, email: row.email });
    res.json({ success: true, user: { id: row.id, name: row.name, email: row.email }, token });
  });
});

app.get('/api/me', authMiddleware, (req, res) => {
  const id = req.user.id;
  db.get('SELECT id, name, email, created_at FROM users WHERE id = ?', [id], (err, row) => {
    if(err) return res.status(500).json({ error: 'DB error' });
    if(!row) return res.status(404).json({ error: 'User not found' });
    res.json({ user: row });
  });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
